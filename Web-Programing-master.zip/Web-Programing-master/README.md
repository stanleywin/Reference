# Web-Programing
只有部分有儲存的程式碼

## Backward sequence
[逆向排列輸入數字](https://github.com/Arick1995/Web-Programing/blob/master/textbox/textbox)

## Split
[讀取單排數字](https://github.com/Arick1995/Web-Programing/blob/master/length/length)

## Circle(Easy)
[圓的面積-按鍵部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle/Button)

[圓的面積-APP部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle/Function_Circle_Easy)


## Circle(Private)
[版本1-Button部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Button1)

[版本1-APP部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/circle_Private_1)

[版本2-Button部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Button2)

[版本2-APP部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/circle_Private_2)

[版本3-Button部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Button3)

[版本3-APP部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/circle_Private_3)


## Item
[Button部分](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Button4)

[Item(商品名字和ID)](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Item.cs)

[Product(價錢)](https://github.com/Arick1995/Web-Programing/blob/master/Circle2/Product.cs)
